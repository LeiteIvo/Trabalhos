def media(b,x):
    a = 0
    for i in b:
        a = a + i
    return a / x

x = int(input("Quantas notas quer inserir: "))
b = []
k = 0
for i in range(1,x + 1):
    y = int(input("Indique um nota: "))
    if y <= 7 or y > 20:
        print("reprovado")
        k = 1
        b.append(i)
        break
    else:
        b.append(y)
    

print(b)
if k != 1:
    w = media(b,x)
    
if w < 10 :
    print("reprovado!")
    print("A sua media é: ", w)
else:
    print("Aprovado")
    print("A sua media é: ", w)


