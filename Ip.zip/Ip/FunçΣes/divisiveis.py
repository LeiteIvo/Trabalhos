def divisiveis(a,b):
    divisiveis = 0
    for i in range(2,a):
        if a % i == 0:
            divisiveis = divisiveis + 1
            break
    for i in range(2, b):
        if b % i == 0:
            divisiveis = divisiveis + 1
            break
    if divisiveis == 2:
        return True
    else: 
        return False
            
        
        
    
x = int(input("Indique um numero: "))
y = int(input("Intrudoza o segundo numero: "))

w = divisiveis(x,y)

if w == True:
    print("Sao numeros divisiveis!")
else:
    print("Numeros nao divisiveis")