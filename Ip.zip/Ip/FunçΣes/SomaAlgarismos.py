def somaalgue(x):
    w = 0
    p = 0
    while x != 0:
        w = x % 10
        x = x // 10
        p = p + w
    return p

x = int(input("intrudoza um numeor: "))

w = somaalgue(x)

print(w)
        