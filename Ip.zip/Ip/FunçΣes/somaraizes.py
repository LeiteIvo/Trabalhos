def somaraizes(a , b):
    from math import sqrt
    return sqrt(a + b)

x = float(input("Indique um numero: "))
y = float(input("Indique o segundo numero: "))

print(somaraizes(x, y ))