def primo(a):
    for i in range(2, a):
        if a % i == 0:
            return False
    return True

x = int(input("Indique um numero para ver se é primo: "))

if primo(x) == True:
    print(x, " é primo.")
else:
    print(x, "não é primo.")