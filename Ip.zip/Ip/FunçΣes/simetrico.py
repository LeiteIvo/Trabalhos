def simetrico(a):
    return a * -1

b = int(input("Indique um numero: "))

print(simetrico(b))
    