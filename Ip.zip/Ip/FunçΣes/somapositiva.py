def soma(x, y):
    if x + y < 0:
        return 0
    else:
        return a + b

a = int(input("Dijite um numero: "))
b = int(input("Dijite outro numero: "))
print(soma(a,b ))