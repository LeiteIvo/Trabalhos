def fibonacci(x):
    num = 1
    lista = str(0)
    fibo = 0
    while fibo <= x:
        lista = lista + " " + str(fibo)
        lista1 = num + fibo
        fibo = num
        num = lista1
        
    return lista

x = int(input("indique o numero que seja transformar em lista Fibonacci: "))

print(fibonacci(x))
        