def funcao(x,a,b):
    from random import randint
    h = []
    for i in range(0, x):
        h.append(randint(a,b))
    return h


h = funcao(20,20, 340)

print(h)