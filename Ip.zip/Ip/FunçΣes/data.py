def data(a,b,c):
    if (a < 1900 or a > 2022 or b < 1 or b > 12 or c < 1 or  c > 31) or (b == 2 and c > 29) or ( b % 2 != 0 and c > 30 ):
        return False
    else:
            return True
        
        
a = int(input("Intrudoza um ano:"))
b = int(input("Intrudoza um mes: "))
x = int(input("Intrudoza um dia: "))

w = data(a,b,x)

if w == True:
    print("Data valida!")
else:
    print("Data nao valida")
        