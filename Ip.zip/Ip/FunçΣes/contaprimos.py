def contpri(x, y):
    Primos = []
   
    for i in range(x, y):
        k = 0
        for j in range(2, i):
            if i % j == 0:
                k = 1 
            if k == 1:
                break
        if k == 0:
            Primos.append(i)
    
    return Primos
        
                


x = int(input("Inidique um numero: "))
y = int(input("Inidique um numero: "))

print(contpri(x, y))