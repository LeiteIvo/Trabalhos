def decrescente(a,b,c):
    if a > b > c:
        return True
    else:
        return False
    
x = int(input("Indi ue um nuemre:"))
y = int(input("Indique o segundo numero: "))
w = int(input("Indique o terceiro nuemero: "))

print(decrescente(x,y,w))