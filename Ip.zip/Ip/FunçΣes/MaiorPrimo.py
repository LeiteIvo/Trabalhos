def maiorprimo(x):
    for i in range(x - 1, 1, -1):
        mprimo = 0
        if i > 0:
            for j in range(2, i - 1):
                if i % j == 0:
                    break
            else:
                return i
           
x = int(input("Indique um numero: "))

b = maiorprimo(x)

print(b)