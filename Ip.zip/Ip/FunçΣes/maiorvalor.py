def valormaior(x,b,w):
    if x >= b and x >= w:
        b = x
        w = x
    if b >= x and b >= w:
        x = b
        w = b
    else:
        b = w
        x = w
    return x, b, w
        

a = int(input("Indique um valor: "))
b = int(input("Indique o segundo valor: "))
c = int(input("Indique o terceiro valor: "))

print(valormaior(a,b,c))

