def desimoprimo(x):
    k = 0
    j = 0
    b = [2]
    for i in range(2, x):
        if x % i == 0:
            k = 0
            break
        else:
            k = 1
    if k == 0:
        for i in range(1, x):
            for w in range(2, i):
                if i % w == 0:
                    j = 0
                    break
                else:
                    j = 1
            if j == 1:
                b.append(i)
    for i in range(0, len(b)):
        if i == 9:
            q = b[i]
            return q
    return "Nao existe "
 

x = int(input("Indique um numero: "))
w = desimoprimo(x)
print(w)