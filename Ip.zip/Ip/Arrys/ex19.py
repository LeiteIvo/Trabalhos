'''Crie um programa para determinar o maior valor entre as 
posições de dois vetores e colocar o resultado num 3º vetor.
'''

from arrays import lista

p = 0

f = []

h = lista(10,1,25)
print(h)

b = lista(10,1,25)
print(b)



for i in range(0, len(h)):
    if h[i] < b[i]:
        f.append(b[i])
    else:
        f.append(h[i])
        
print(f)