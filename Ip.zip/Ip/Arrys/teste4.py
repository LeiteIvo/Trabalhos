'''Desenvolva um programa que receba uma lista de nú
meros e calcule a soma cumulativa, ou seja, o programa deve retornar uma nova lista em que o elemento de ordem i é a soma dos primeiros i elementos da lista original. 
Exemplo: para [1, 2, 3] deve devolver [1, 3, 6].'''

from arrays import lista

h = lista(5,1,10)
print(h)
comolativo = []
numero = 0
numero2 = 0
soma = 0
for i in range(0, len(h)):
    numero = h[i]
    soma = numero + numero2
    comolativo.append(soma)
    numero2 = soma
    
print(comolativo)
