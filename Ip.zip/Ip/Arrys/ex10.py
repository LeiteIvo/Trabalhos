'''10) Escreva um programa que preencha um vetor de 20 posições com 
os primeiros 20 números primos.'''


h = [2]
eprimo = 0
for i in range(1, 200):
    if len(h) == 20:
        break
    else:
        for x in range(2, i):
            if i % x == 0:
                eprimo = 0
                break
            else:
                eprimo = 1
    if eprimo == 1:
        h.append(i)

print(h)

for i in range(1, 20):
    print("ola")
