'''Crie um programa que leia um vetor de 10 inteiros. Os valores 
deverão estar no intervalo [0,100]. O programa não deverá aceitar 
valores fora deste intervalo. O programa deverá indicar a soma dos 
inteiros múltiplos de 5 existentes no vetor. '''

from arrays import lista
soma = 0
x = lista(10,0,100)

print(x)

for i in x:
    if i % 5 == 0:
        soma = soma + i
        
print(soma)       