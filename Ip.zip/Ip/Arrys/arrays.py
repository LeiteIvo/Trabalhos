def lista(x,a,b):
    from random import randint
    h = []
    for i in range(0, x):
        h.append(randint(int(a),int(b)))
    return h


