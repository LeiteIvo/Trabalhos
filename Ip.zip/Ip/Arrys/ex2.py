# Escreva um programa que procure e indique o maior valor (e a 
#respetiva posição) de um vetor de 10 posições introduzido pelo 
#utilizador.""

from random import randint
max = 0
b = []

for i in range(1, 11):
    x = int(input("Indique um numero para inserir na lista: "))
    b.append(x)
    
for i in range(0,len(b)):
    if b[i] > max:
        max = b[i]
        h = i
print(b)
print(max, " na posiçâo", h + 1)