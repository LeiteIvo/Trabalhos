'''Crie um programa que simule 100 lançamentos de 2 dados, guarde 
os resultados em vetores e produza uma estatística.'''

from arrays import lista

x = lista(100,0,50)

y = lista(100,0,25) 

if b