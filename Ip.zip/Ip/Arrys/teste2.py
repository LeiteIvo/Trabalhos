'''Dada uma lista de N valores inteiros, coloque os números pares na primeira metade da lista e os números ímpares na segunda metade da lista.

Ex: N: 5 -> [24, 15, 30, 13, 34]

A: [24, 34, 30, 13, 15]'''

from arrays import lista

lista1 = lista(20,1,30)
print(lista1)

lista2 = []

tamanho = len(lista1)

for i in range(0,tamanho):
    if lista1[i] % 2 == 0:
        lista2.append(lista1[i])
        print(lista2)
        
for i in range(0, len(lista1)):
    if lista1[i] % 2 != 0:
        lista2.append(lista1[i])  
        print(lista2)      
        


print(lista1)