'''Escreva um programa que inverta a ordem dos elementos de um 
vetor de inteiros. Compare os resultados com a função reverse.'''
from arrays import lista

h = lista(15,0 , 100)
print(h)

p = []
t = len(h)


for x in range(len(h) -1 , -1,-1):
    p.append(h[x])

print(p)    
h.reverse()
print(h)