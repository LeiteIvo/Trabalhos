#Escreva um programa que determine o 2º maior valor de um vetor.
from arrays import funcao

b = funcao(10, 5,100)
max = 0

print(b)

max2 = 0
for i in range(0, len(b)):
    if b[i] > max:
        max2 = max
        max = b[i]
    else:
        if b[i] > max2:
            max2 = b[i]
        
  
b.pop(i)    


        
print(max2)
    

