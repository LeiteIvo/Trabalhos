"""Crie um programa que leia um vetor de n inteiros, sendo n um 
valor introduzido pelo utilizador, não havendo restrições. O 
programa deverá converter todos os valores negativos do vetor para 
0, imprimir o vetor resultante e indicar quantos valores foram 
alterados. """

from arrays import lista

n = int(input("Indique o tamanho da lista"))
b = lista(n, -100, 100)

for i in range(0, len(b)):
    if b[i] < 0:
        b[i] = 0

print(b)
