''' Desenvolva um programa para simular o embaralhar de um baralho 
de cartas. Use um vetor e embaralhe as cartas fazendo trocas entre 
os elementos. Depois dê 4 mãos de 13 cartas.'''

from random import randint
from array import lista
h = lista(52,0,0)
m = []
m1 = []
m2 = []
m3 = []

for i in range(1,5):
    print(h)

for i in range(1, 5):
    m.append()
    