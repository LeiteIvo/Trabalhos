'''Escreva um programa que peça as idades de 32 alunos de uma 
turma. O programa deve guardar estes valores num vetor e no final 
indicar a idade máxima, mínima média e moda da turma.'''

from arrays import lista

h = lista(32, 14,16)
soma = 0
maximo = 0
minimo = 0
contar = 0
moda = 0
print(h)

for i in range(0,len(h)):
    soma = soma + h[i]
    if h[i] > maximo:
        maximo = h[i]
    if minimo > h[i]:
        minimo = h[i]
    if h.count(h[i]) > contar:
        contar = h.count(h[i])
        moda = h[i]
    
print('A media é doss numeros é: ', soma / (len(h) + 1))
print('O maximo é:', maximo)
print('A moda é', moda,'e é repetido', contar)
