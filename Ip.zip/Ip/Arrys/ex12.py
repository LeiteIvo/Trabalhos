''' Escreva um programa que indique se todos os valores de um 
vetor são iguais, se são todos diferentes, ou se há valores 
repetidos no vetor. Para testar utilize um vetor cujo tamanho e 
valores inteiros são introduzidos pelo utilizador. '''

x = int(input('indique o tamanho da lista que deseja: '))
b = []
tudoigual = 0
diferente = 0
numeroigual = 0
for i in range(1, x + 1):
    x = int(input('Inntrudoza o valor para intrudozir na lissta: '))
    b.append(x)
print(b)

for i in range(1, len(b)):
    if b[i - 1] == b[i]:
        tudoigual = 1
    else:
        tudoigual = 0
        break

if tudoigual == 1:
    print('É tudo igual')

if tudoigual == 0:  
    for i in range(0, len(b)):
        for q in range(0, len(b)):
            if i != q:
                diferente = 1
            else:
                diferente = 0
                print('Nem todos os valores sao diferente ')
                break
        if diferente == 0:
            break
                
if diferente == 0 and tudoigual == 0:
    for i in range(0, len(b)):
        for q in range(1, len(b)):
            if i == q:
                print('O numero', b[i] ,'é repetido na posição ', q + 1, )