'''Escreva um programa para determinar o valor mais comum (moda) 
num vetor de inteiros. Teste com um vetor de 100 posições preenchido 
aleatoriamente com valores entre 0 e 10. '''

from arrays import lista

h = lista(100,0,10)
print(h)

contar = 0
moda = 0

for i in range(0,len(h)):
    if h.count(h[i]) > contar:
        contar = h.count(h[i])
        moda = h[i]
        
print(moda, ' repete-se, ', contar)