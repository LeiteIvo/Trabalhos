'''Crie um programa que conte o número de números primos num 
vetor de inteiros. '''

from arrays import lista

h = lista(10,0,100)
primo = 0

for i in range(0, len(h)):
    eprimo = 0
    for x in range(2,h[i]):
        if h[i] == 2:
            primo += 1
            break
        else:
            if h[i] % x == 0:
                eprimo = 0
                break
            else:
                eprimo = 1
    if eprimo == 1:
        primo += 1
        
            
print(h)
print(primo)