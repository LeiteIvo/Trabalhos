"""Crie um programa que leia um conjunto de valores inteiros do 
utilizador e os coloque num vetor. O programa deverá terminar a 
leitura quando for introduzido um número que já exista no vetor, ou 
seja, quando for introduzido um número repetido. No final deverá 
apresentar o vetor."""

b = []
x = 0
y = 1
l = int(input("Indique o primeiro numero: "))
b.append(l)
while True:
    x = int(input("Indique um numero para inserir na lista: "))
    for k in range(0,len(b)):
        if x == b[k]:
             y = 0
             break
    if y == 0:
        break
    else:
        b.append(x)
        
print(b)