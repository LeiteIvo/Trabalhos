'''Escreva um programa que verifique se todos os elementos de um 
determinado vetor existem noutro vetor.'''

from arrays import lista

h = lista(10,0, 100)
igual = 0
p = h[:]
p[3] = 1

print(h)
print(p)

for i in range(0, len(h)):
    if h[i] == p[i]:
        igual = 1
    else:
        igual = 0
        break
        
if igual == 1:
    print('Tudo fixe')
else:
    print('Nada fixe')

