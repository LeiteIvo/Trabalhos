"""Escreva um programa em que 20 valores inteiros entre 1 e 10 são 
introduzidos pelo utilizador num vetor. Depois, o utilizador deverá 
indicar um valor e o programa deverá indicar em que posição ou 
posições, este valor existe no vetor. Se o valor não existir no 
vetor o programa deverá dar a respetiva mensagem."""

h = 0
b= []
x = 0
for i in range(1, 21):
    x = int(input("Intrudoza um valor entre 1 a 10: "))
    while x < 1 or x > 10:
        x = int(input("Indique um valor entre 1 a 10 ESTUPIDO: "))
    b.append(x)

n = 20
i = 1    
while i <= n:
    x = int(input(f"Introduza um valor entre 1 a 10: "))
    if x < 1 or x > 10:
        print("sdfsdfsdf")
    else:
        i += 1
        b.append(x)
        
        
    
print(b)

d = int(input("Indique o numero que quer localizar: "))

for i in range(0, len(b)):
    if d == b[i]:
        h = i + 1
        print("O seu numero que procura ", d, " Localiza-se em, ", h)
        b[i] = 100
        

