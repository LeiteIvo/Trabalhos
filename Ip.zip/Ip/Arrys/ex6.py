""" Crie um programa que leia um vetor de 10 valores inteiros do 
utilizador, não permitindo a introdução de valores repetidos."""

b = []
x = 0
l = int(input("Indique o primeiro numero: "))
b.append(l)
for i in range(0,10):
    x = int(input("Indique um numero para inserir na lista: "))
    for k in range(0,len(b)):
        while x == b[k]:
             x = int(input("Indique um numero para inserir na lista que não seja repetido: "))
    b.append(x)
        
print(b)