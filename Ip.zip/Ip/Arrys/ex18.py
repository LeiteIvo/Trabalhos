''' Crie um programa para somar 2 vetores de tamanhos diferentes 
e colocar o resultado num 3º vetor.'''

from arrays import lista

h = lista(10, 0, 20)
print(h)
p = lista(13, 0, 25)
print(p)

m = h[:]

for i in range(0, len(p)):
    if i > len(m) - 1:
        m.append(p[i])
    else:
        m[i] = m[i] + p[i]
        
print(m)

