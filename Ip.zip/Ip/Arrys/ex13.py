''' Crie um programa que leia um vetor de inteiros cujo tamanho 
será introduzido pelo utilizador, tamanho esse que nunca será 
inferior a 5 ou superior a 25. O programa deverá indicar ao 
utilizador se o vetor é constituído (ou não) por valores pares e 
ímpares alternados. Exemplo: O vetor [1, 2, 5, 6, 3, 2] verifica 
esta condição.
'''

x = 0
b = []
tudoalternado = 0
k = 0
while x < 5 or x > 25:
    x = int(input('Indiquee um numerro para o tamanha da lista enntre 5 e 25: '))
    
for i in range(1, x + 1):
    p = int(input('Indique o valor para inttrudozir na lisa: '))
    b.append(p)
    
for i  in range(0, len(b)):
    k = i + 1
    if i == x - 1:
            break
    else:
        if (b[i] % 2 == 0 and b[k] % 2 == 0) or (b[i] % 2 != 0 and b[k] % 2 != 0):
            print('Nao é aternado')
            tudoalternado = 0
            break
        else:
            tudoalternado = 1
    if tudoalternado == 0:
        break

if tudoalternado == 1:
    print('Esta lista é altenada')