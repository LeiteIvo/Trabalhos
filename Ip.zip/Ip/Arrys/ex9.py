"""Crie um programa que leia 10 números float, coloque-os num vetor
e calcule a sua média."""

x = 0
b = []
soma = 0
for i in range(1,11):
    x  = float(input("Indique um numero float para inserir na lista: "))
    b.append(x)

for i in range(0, len(b)):
    soma = soma + b[i]

print(soma / (len(b) + 1))
