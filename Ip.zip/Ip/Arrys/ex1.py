# 1) Escreva um programa que preencha um vetor de 100 posições com os 
# primeiros 100 números pares. 
from random import randint 


b = []

for j in range(2, 201, 2):
    b.append(j)
        
print(b)
    
