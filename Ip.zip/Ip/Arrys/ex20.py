"""Crie um programa que simule 100 lançamentos de 2 dados, guarde 
os resultados em vetores e produza uma estatística. """

from arrays import lista

vinte = 0
vinte1 = 0

h = lista(50,1,100)

v = lista(50,1,100)

print(h)
print(v)

for i in range(0, len(h)):
    if h[i] == 20:
        vinte += 1
    if v[i] == 20:
        vinte1 += 1
        
print((vinte / (len(h) + 1)) * 100, "%. ")
print((vinte1 / (len(h) + 1)) * 100, "%. ")

lol = 5 // 2
print(lol)
