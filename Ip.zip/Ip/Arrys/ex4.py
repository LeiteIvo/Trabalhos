# Crie um programa que apresente a soma de todos os valores de um 
#vetor de inteiros de 10 posições. Os valores devem ser introduzidos 
#pelo utilizador. 

b = []
soma = 0
conta = "A soma dos numeros: "

for i in range(1, 11):
    x = int(input("Indique um numero de random para inserir na lista: "))
    b.append(x)
    
for x in b:
    conta = conta + str(x) + " + " 
    soma = soma + x
    
print(conta, " é ", soma)