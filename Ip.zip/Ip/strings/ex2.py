""" Altere o programa de modo a que se o nome for "Bartolomeu", o programa 
imprima "Dá cá o meu!"."""

nome = str(input("Indique o seu nome: "))

if (nome == "bartolomeu") or (nome == "Bartolomeu"):
    print("Dá cá o meu")

