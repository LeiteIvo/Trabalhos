"""Crie um programa que leia o nome próprio do utilizador e imprima uma 
mensagem personalizada do tipo: "Olá João!"""

nome = str(input(" Indique o seu nome: "))

print(" Olá", nome," !!")